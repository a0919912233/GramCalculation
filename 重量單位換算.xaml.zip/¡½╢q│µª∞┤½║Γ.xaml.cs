﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtMg_KeyUp(object sender, KeyEventArgs e)
        {
            double douMg;
            douMg = Convert.ToDouble(txtMg.Text); 

           
            txtG.Text = string.Format("{0:0.##########}", douMg / 1000);
            txtKg.Text = string.Format("{0:0.##########}", douMg / 1000000);
            txtT.Text = string.Format("{0:0.##########}", douMg / 1000000000);
            txtOz.Text = string.Format("{0:0.##########}", douMg / 453592.4);
            txtLb.Text = string.Format("{0:0.##########}", douMg / 28349.52);
        }

        private void txtG_KeyUp(object sender, KeyEventArgs e)
        {
            double douG;
            douG = Convert.ToDouble(txtG.Text);


            txtMg.Text = string.Format("{0:0.##########}", douG / 0.001);
            txtKg.Text = string.Format("{0:0.##########}", douG / 1000);
            txtT.Text = string.Format("{0:0.##########}", douG / 1000000);
            txtOz.Text = string.Format("{0:0.##########}", douG / 453.5924);
            txtLb.Text = string.Format("{0:0.##########}", douG / 28.34952);
        }

        private void txtKg_KeyUp(object sender, KeyEventArgs e)
        {
            double douKg;
            douKg = Convert.ToDouble(txtKg.Text);


            txtMg.Text = string.Format("{0:0.##########}", douKg / 0.000001);
            txtG.Text = string.Format("{0:0.##########}", douKg /0.001);
            txtT.Text = string.Format("{0:0.##########}", douKg / 1000);
            txtOz.Text = string.Format("{0:0.##########}", douKg / 0.4535924);
            txtLb.Text = string.Format("{0:0.##########}", douKg / 0.02834952);
        }

        private void txtT_KeyUp(object sender, KeyEventArgs e)
        {
            double douT;
            douT = Convert.ToDouble(txtT.Text);


            txtMg.Text = string.Format("{0:0.##########}", douT / 0.000000001);
            txtG.Text = string.Format("{0:0.##########}", douT / 0.000001);
            txtKg.Text = string.Format("{0:0.##########}", douT / 0.001);
            txtOz.Text = string.Format("{0:0.##########}", douT / 0.0004535924);
            txtLb.Text = string.Format("{0:0.##########}", douT / 0.00002834952);
        }

        private void txtOz_KeyUp(object sender, KeyEventArgs e)
        {
            double douOz;
            douOz = Convert.ToDouble(txtOz.Text);


            txtMg.Text = string.Format("{0:0.##########}", douOz / 0.00003527396);
            txtG.Text = string.Format("{0:0.##########}", douOz / 0.03527396);
            txtKg.Text = string.Format("{0:0.##########}", douOz / 35.27396);
            txtT.Text = string.Format("{0:0.##########}", douOz / 35273.96);
            txtLb.Text = string.Format("{0:0.##########}", douOz / 16);
        }

        private void txtLb_KeyUp(object sender, KeyEventArgs e)
        {
            double douLb;
            douLb = Convert.ToDouble(txtLb.Text);


            txtMg.Text = string.Format("{0:0.##########}", douLb / 0.000002204623);
            txtG.Text = string.Format("{0:0.##########}", douLb / 0.002204623);
            txtKg.Text = string.Format("{0:0.##########}", douLb / 2.204623);
            txtT.Text = string.Format("{0:0.##########}", douLb / 2204.623);
            txtOz.Text = string.Format("{0:0.##########}", douLb / 0.0625);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            txtMg.Text = "";
            txtG.Text = "";
            txtKg.Text = "";
            txtT.Text = "";
            txtOz.Text = "";
            txtLb.Text = "";
        }
    }
}
